import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false};import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=bc399844"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=bc399844"; const StrictMode = __vite__cjsImport1_react["StrictMode"];
import __vite__cjsImport2_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=bc399844"; const createRoot = __vite__cjsImport2_reactDom_client["createRoot"];
import App from "/src/App.tsx?t=1767113594024";
import "/src/index.css?t=1767113594024";
import { initSentry } from "/src/utils/sentry.ts";
import { validateProductionEnvironment } from "/src/utils/environmentValidator.ts";
validateProductionEnvironment();
initSentry();
if (import.meta.env.PROD) {
  import("/src/hooks/usePerformanceMonitoring.ts").then(() => {
  });
}
const rootElement = document.getElementById("root");
if (!rootElement) {
  throw new Error("Failed to find the root element");
}
createRoot(rootElement).render(
  /* @__PURE__ */ jsxDEV(StrictMode, { children: /* @__PURE__ */ jsxDEV(App, {}, void 0, false, {
    fileName: "C:/Users/facel/Downloads/GitHub/ERMITS_PRODUCTION/05-vendorsoluce/src/main.tsx",
    lineNumber: 29,
    columnNumber: 5
  }, this) }, void 0, false, {
    fileName: "C:/Users/facel/Downloads/GitHub/ERMITS_PRODUCTION/05-vendorsoluce/src/main.tsx",
    lineNumber: 28,
    columnNumber: 3
  }, this)
);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEJJO0FBNUJKLFNBQVNBLGtCQUFrQjtBQUMzQixTQUFTQyxrQkFBa0I7QUFDM0IsT0FBT0MsU0FBUztBQUNoQixPQUFPO0FBQ1AsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLHFDQUFxQztBQUc5Q0EsOEJBQThCO0FBRzlCRCxXQUFXO0FBR1gsSUFBSUUsWUFBWUMsSUFBSUMsTUFBTTtBQUN4QixTQUFPLGtDQUFrQyxFQUFFQyxLQUFLLE1BQU07QUFBQSxFQUNwRCxDQUNEO0FBQ0g7QUFFQSxNQUFNQyxjQUFjQyxTQUFTQyxlQUFlLE1BQU07QUFFbEQsSUFBSSxDQUFDRixhQUFhO0FBQ2hCLFFBQU0sSUFBSUcsTUFBTSxpQ0FBaUM7QUFDbkQ7QUFFQVgsV0FBV1EsV0FBVyxFQUFFSTtBQUFBQSxFQUN0Qix1QkFBQyxjQUNDLGlDQUFDLFNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFJLEtBRE47QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBO0FBQ0YiLCJuYW1lcyI6WyJTdHJpY3RNb2RlIiwiY3JlYXRlUm9vdCIsIkFwcCIsImluaXRTZW50cnkiLCJ2YWxpZGF0ZVByb2R1Y3Rpb25FbnZpcm9ubWVudCIsImltcG9ydCIsImVudiIsIlBST0QiLCJ0aGVuIiwicm9vdEVsZW1lbnQiLCJkb2N1bWVudCIsImdldEVsZW1lbnRCeUlkIiwiRXJyb3IiLCJyZW5kZXIiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsibWFpbi50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgU3RyaWN0TW9kZSB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgY3JlYXRlUm9vdCB9IGZyb20gJ3JlYWN0LWRvbS9jbGllbnQnO1xyXG5pbXBvcnQgQXBwIGZyb20gJy4vQXBwLnRzeCc7XHJcbmltcG9ydCAnLi9pbmRleC5jc3MnO1xyXG5pbXBvcnQgeyBpbml0U2VudHJ5IH0gZnJvbSAnLi91dGlscy9zZW50cnknO1xyXG5pbXBvcnQgeyB2YWxpZGF0ZVByb2R1Y3Rpb25FbnZpcm9ubWVudCB9IGZyb20gJy4vdXRpbHMvZW52aXJvbm1lbnRWYWxpZGF0b3InO1xyXG5cclxuLy8gVmFsaWRhdGUgZW52aXJvbm1lbnQgY29uZmlndXJhdGlvblxyXG52YWxpZGF0ZVByb2R1Y3Rpb25FbnZpcm9ubWVudCgpO1xyXG5cclxuLy8gSW5pdGlhbGl6ZSBTZW50cnkgZXJyb3IgdHJhY2tpbmdcclxuaW5pdFNlbnRyeSgpO1xyXG5cclxuLy8gSW5pdGlhbGl6ZSBwZXJmb3JtYW5jZSBtb25pdG9yaW5nXHJcbmlmIChpbXBvcnQubWV0YS5lbnYuUFJPRCkge1xyXG4gIGltcG9ydCgnLi9ob29rcy91c2VQZXJmb3JtYW5jZU1vbml0b3JpbmcnKS50aGVuKCgpID0+IHtcclxuICAgIC8vIFBlcmZvcm1hbmNlIG1vbml0b3Jpbmcgd2lsbCBiZSBpbml0aWFsaXplZCB3aGVuIGNvbXBvbmVudHMgbW91bnRcclxuICB9KTtcclxufVxyXG5cclxuY29uc3Qgcm9vdEVsZW1lbnQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncm9vdCcpO1xyXG5cclxuaWYgKCFyb290RWxlbWVudCkge1xyXG4gIHRocm93IG5ldyBFcnJvcignRmFpbGVkIHRvIGZpbmQgdGhlIHJvb3QgZWxlbWVudCcpO1xyXG59XHJcblxyXG5jcmVhdGVSb290KHJvb3RFbGVtZW50KS5yZW5kZXIoXHJcbiAgPFN0cmljdE1vZGU+XHJcbiAgICA8QXBwIC8+XHJcbiAgPC9TdHJpY3RNb2RlPlxyXG4pOyJdLCJmaWxlIjoiQzovVXNlcnMvZmFjZWwvRG93bmxvYWRzL0dpdEh1Yi9FUk1JVFNfUFJPRFVDVElPTi8wNS12ZW5kb3Jzb2x1Y2Uvc3JjL21haW4udHN4In0=