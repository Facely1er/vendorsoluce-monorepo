/**
 * Script to reorder sections in index.html to match ERMITS 7-Section Framework
 * 
 * Required Order:
 * 1. HERO SECTION
 * 2. PROBLEM SECTION  
 * 3. SOLUTION SECTION
 * 4. PROOF SECTION
 * 5. FEATURES SECTION
 * 6. PRICING SECTION
 * 7. ACTION SECTION
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const htmlFile = path.join(__dirname, 'index.html');
const htmlContent = fs.readFileSync(htmlFile, 'utf8');

// Extract sections using regex patterns
const sectionPatterns = {
  hero: /<section[^>]*class="[^"]*relative[^"]*text-white[^"]*py-16[^"]*"[^>]*>[\s\S]*?<\/section>/,
  problem: /<section[^>]*>[\s\S]*?The real problem: vendor risk is "managed" without verification[\s\S]*?<\/section>/,
  solution: /<section[^>]*>[\s\S]*?Outcomes procurement, security, and auditors recognize[\s\S]*?<\/section>/,
  workflow: /<section[^>]*>[\s\S]*?The VendorSoluce workflow[\s\S]*?<\/section>/,
  proof: /<section[^>]*>[\s\S]*?Proof you can use in supplier and procurement reviews[\s\S]*?<\/section>/,
  features: /<section[^>]*id="features"[^>]*>[\s\S]*?Core capabilities[\s\S]*?<\/section>/,
  pricing: /<section[^>]*>[\s\S]*?<h2[^>]*>Pricing<\/h2>[\s\S]*?<\/section>/,
  action: /<section[^>]*>[\s\S]*?Next step[\s\S]*?<\/section>/
};

// Extract all sections
const sections = {};
for (const [key, pattern] of Object.entries(sectionPatterns)) {
  const match = htmlContent.match(pattern);
  if (match) {
    sections[key] = match[0];
  }
}

// Find the main content area
const mainStart = htmlContent.indexOf('<main');
const mainEnd = htmlContent.indexOf('</main>') + '</main>'.length;
const beforeMain = htmlContent.substring(0, mainStart);
const afterMain = htmlContent.substring(mainEnd);

// Reorder sections according to ERMITS 7-Section Framework
// Remove workflow section (not part of the 7-section framework)
const orderedSections = [
  sections.hero,
  sections.problem,
  sections.solution,
  sections.proof,
  sections.features,
  sections.pricing,
  sections.action
].filter(Boolean); // Remove undefined sections

// Reconstruct HTML
const newMainContent = `<main class="flex-1">${orderedSections.join('')}</main>`;
const newHtmlContent = beforeMain + newMainContent + afterMain;

// Write the reordered HTML
fs.writeFileSync(htmlFile, newHtmlContent, 'utf8');

console.log('✅ Sections reordered successfully!');
console.log('✅ Removed workflow section (not part of 7-section framework)');
console.log('✅ Sections now follow ERMITS 7-Section Framework order:');
console.log('   1. Hero');
console.log('   2. Problem');
console.log('   3. Solution');
console.log('   4. Proof');
console.log('   5. Features');
console.log('   6. Pricing');
console.log('   7. Action');

